(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('react'), require('react-dom'), require('prop-types'), require('react-form-with-constraints')) :
    typeof define === 'function' && define.amd ? define(['exports', 'react', 'react-dom', 'prop-types', 'react-form-with-constraints'], factory) :
    (global = global || self, factory(global.ReactFormWithConstraintsTools = {}, global.React, global.ReactDOM, global.PropTypes, global.ReactFormWithConstraints));
}(this, function (exports, React, ReactDOM, PropTypes, reactFormWithConstraints) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    function __values(o) {
        var m = typeof Symbol === "function" && o[Symbol.iterator], i = 0;
        if (m) return m.call(o);
        return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
    }

    var DisplayFields = (function (_super) {
        __extends(DisplayFields, _super);
        function DisplayFields() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.reRender = function () {
                _this.forceUpdate();
            };
            return _this;
        }
        DisplayFields.prototype.componentWillMount = function () {
            var form = this.context.form;
            form.fieldsStore.addListener(reactFormWithConstraints.FieldEvent.Added, this.reRender);
            form.fieldsStore.addListener(reactFormWithConstraints.FieldEvent.Removed, this.reRender);
            form.addFieldDidValidateEventListener(this.reRender);
            form.addFieldDidResetEventListener(this.reRender);
        };
        DisplayFields.prototype.componentWillUnmount = function () {
            var form = this.context.form;
            form.fieldsStore.removeListener(reactFormWithConstraints.FieldEvent.Added, this.reRender);
            form.fieldsStore.removeListener(reactFormWithConstraints.FieldEvent.Removed, this.reRender);
            form.removeFieldDidValidateEventListener(this.reRender);
            form.removeFieldDidResetEventListener(this.reRender);
        };
        DisplayFields.prototype.render = function () {
            var str = stringifyWithUndefinedAndWithoutPropertyQuotes(this.context.form.fieldsStore.fields, 2);
            str = str.replace(/{\s+key: (.*),\s+type: (.*),\s+show: (.*)\s+}/g, '{ key: $1, type: $2, show: $3 }');
            return React.createElement("pre", { style: { fontSize: 'small' } },
                "Fields = ",
                str);
        };
        DisplayFields.contextTypes = {
            form: PropTypes.instanceOf(reactFormWithConstraints.FormWithConstraints).isRequired
        };
        return DisplayFields;
    }(React.Component));
    var stringifyWithUndefinedAndWithoutPropertyQuotes = function (obj, space) {
        var str = JSON.stringify(obj, function (_key, value) { return value === undefined ? '__undefined__' : value; }, space);
        str = str.replace(/"__undefined__"/g, 'undefined');
        str = str.replace(/"([^"]+)":/g, '$1:');
        return str;
    };
    var FieldFeedbacks = (function (_super) {
        __extends(FieldFeedbacks, _super);
        function FieldFeedbacks() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        FieldFeedbacks.prototype.render = function () {
            var _a = this.props, fieldName = _a.for, stop = _a.stop;
            var attr = '';
            if (fieldName)
                attr += "for=\"" + fieldName + "\" ";
            attr += "stop=\"" + stop + "\"";
            return (React.createElement(React.Fragment, null,
                React.createElement("li", null,
                    "key=\"",
                    this.key,
                    "\" ",
                    attr),
                React.createElement("ul", null, _super.prototype.render.call(this))));
        };
        return FieldFeedbacks;
    }(reactFormWithConstraints.FieldFeedbacks));
    var FieldFeedback = (function (_super) {
        __extends(FieldFeedback, _super);
        function FieldFeedback() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        FieldFeedback.prototype.getTextDecoration = function () {
            var show = this.state.validation.show;
            var textDecoration = '';
            switch (show) {
                case false:
                    textDecoration = 'line-through';
                    break;
                case undefined:
                    textDecoration = 'line-through dotted';
                    break;
            }
            return textDecoration;
        };
        FieldFeedback.prototype.render = function () {
            var _a = this.state.validation, key = _a.key, type = _a.type;
            return (React.createElement("li", null,
                React.createElement("span", { style: { textDecoration: this.getTextDecoration() } },
                    "key=\"",
                    key,
                    "\" type=\"",
                    type,
                    "\""),
                ' ',
                _super.prototype.render.call(this)));
        };
        FieldFeedback.prototype.componentDidUpdate = function () {
            var e_1, _a;
            var el = ReactDOM.findDOMNode(this);
            var fieldFeedbackSpans = el.querySelectorAll('[data-feedback]');
            try {
                for (var fieldFeedbackSpans_1 = __values(fieldFeedbackSpans), fieldFeedbackSpans_1_1 = fieldFeedbackSpans_1.next(); !fieldFeedbackSpans_1_1.done; fieldFeedbackSpans_1_1 = fieldFeedbackSpans_1.next()) {
                    var fieldFeedbackSpan = fieldFeedbackSpans_1_1.value;
                    fieldFeedbackSpan.style.display = 'inline';
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (fieldFeedbackSpans_1_1 && !fieldFeedbackSpans_1_1.done && (_a = fieldFeedbackSpans_1.return)) _a.call(fieldFeedbackSpans_1);
                }
                finally { if (e_1) throw e_1.error; }
            }
            var li = el.closest('li.async');
            if (li !== null) {
                var async = li.querySelector('span[style]');
                async.style.textDecoration = this.getTextDecoration();
            }
            var type = this.state.validation.type;
            if (type === reactFormWithConstraints.FieldFeedbackType.WhenValid) {
                var span = el.querySelector('span[style]');
                var whenValid = el.querySelector("span." + this.props.classes.valid);
                span.style.textDecoration = whenValid !== null ? '' : 'line-through';
            }
        };
        return FieldFeedback;
    }(reactFormWithConstraints.FieldFeedback));
    var Async = (function (_super) {
        __extends(Async, _super);
        function Async() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        Async.prototype.getTextDecoration = function () {
            return 'line-through dotted';
        };
        Async.prototype.componentWillUpdate = function () {
            var el = ReactDOM.findDOMNode(this);
            var async = el.querySelector('span[style]');
            async.style.textDecoration = this.getTextDecoration();
        };
        Async.prototype.render = function () {
            return (React.createElement("li", { className: "async" },
                React.createElement("span", { style: { textDecoration: this.getTextDecoration() } }, "Async"),
                React.createElement("ul", null, _super.prototype.render.call(this))));
        };
        return Async;
    }(reactFormWithConstraints.Async));

    exports.FormWithConstraints = reactFormWithConstraints.FormWithConstraints;
    exports.DisplayFields = DisplayFields;
    exports.FieldFeedbacks = FieldFeedbacks;
    exports.FieldFeedback = FieldFeedback;
    exports.Async = Async;

    Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=react-form-with-constraints-tools.development.js.map
